import 'dotenv/config';
import express from 'express';
import path from 'path';
import { db } from './db/config.js';
import { mainRouter } from './src/api/routes.js';
import { errorHandler } from './src/middleware/error-handler.js';
import { resumeProcessingDocumentsService } from './src/api/rag/service/rag.service.js';
import cors from 'cors';

const app = express();
const port = process.env.PORT || 8000;

// Middleware
app.use(cors());
// for reading json body
app.use(express.json());
// for reading plaintext (required for Telebirr webhook encrypted callback)
app.use(express.text({ type: ['text/plain', 'text/*'] }));
// for reading form data and files
app.use(express.urlencoded({ extended: true }));
app.use(
  '/uploads/profile',
  express.static(path.resolve(process.cwd(), 'uploads/profile'), { maxAge: '1d' }),
);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

app.use('/api', mainRouter);

app.use(errorHandler);

// Start server
const startServer = async () => {
  try {
    // Test database connection
    const connection = await db.getConnection();

    console.log('Database connection established successfully.');
    connection.release();

    app.listen(port, err => {
      if (err) {
        console.error('Failed to start the server:', err.message);
        process.exit(1);
      }
      console.log(`Server running on port http://localhost:${port}`);
      resumeProcessingDocumentsService()
        .then(count => {
          if (count > 0) {
            console.log(`[RAG] Resuming ${count} pending document(s).`);
          }
        })
        .catch(error => {
          console.error('[RAG] Could not resume pending documents:', error.message);
        });
    });
  } catch (error) {
    console.error(
      'Failed to connect to the database. Server not started.',
      error.message,
    );
    process.exit(1);
  }
};

startServer();
