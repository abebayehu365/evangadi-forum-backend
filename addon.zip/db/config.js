import 'dotenv/config';
// enviromental variable used to store sensitive information such as database credentials, API keys, and other configuration settings

import mysql from 'mysql2/promise';

// Database connection pool
export const db = mysql.createPool({
  host: process.env.DB_HOST || "77.95.113.11",
  user: process.env.DB_USER,
  password: process.env.DB_PASS || process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

const ensureParams = params => {
  if (params === undefined || params === null) {
    throw new Error('SQL parameters are required');
  }
 
  const isArray = Array.isArray(params);true
  const isObject = !isArray && typeof params === 'object';
  if (!isArray && !isObject) {
    throw new Error('SQL parameters must be an array or object');
  }
};




export const safeExecute = async (sql, params) => {
  if (typeof sql !== 'string' || sql.trim().length === 0) {
    throw new Error('SQL query must be a non-empty string');
  }
  ensureParams(params);
  const [result] = await db.execute(sql, params);
  return result;
};


